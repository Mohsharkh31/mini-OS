void kernel_main() {
    const char *msg = "Welcome to my OS! I'm Your Host Abu-Sharkh!!";
    char *vga = (char *)0xB8000;

    for (int i = 0; msg[i] != '\0'; i++) {
        vga[i * 2]     = msg[i];
        vga[i * 2 + 1] = 0x07;
    }

    while (1) __asm__("hlt");
}
